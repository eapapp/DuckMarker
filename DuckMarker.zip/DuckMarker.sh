#!/bin/bash
python ./duckmarker.py